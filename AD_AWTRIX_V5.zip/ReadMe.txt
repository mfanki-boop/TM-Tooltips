The listed Gif-files below are made by myself! Your are not allowed to use them otherwise than in this script!

By Fanki:

-B_1
-B_2
-B_3
-B_4

-HF_1
-HF_2
-HLS_1
-HLS_2
-HLS_4
-HLS_5